URL ="https://www.amazon.in/"
CHROME_PATH = "./resources/drivers/chromedriver.exe"
FIREFOX_PATH = "./resources/drivers/geckodriver.exe"
EXCEL_PATH = "./resources/data/amazon_excel.xlsx"