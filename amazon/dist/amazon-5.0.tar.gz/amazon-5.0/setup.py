from setuptools import setup, find_packages
setup(
      name='amazon',
      version='5.0',
      packages=find_packages(exclude=['test-scripts'])
      )